import UIKit
import Foundation
import Darwin

//MARK: - @propertyWrapper

/*
 @propertyWrapper
 struct UserDefault<Value> {
 let key: String
 let defaultValue: Value
 
 init(key: String, defaultValue: Value) {
 self.key = key
 self.defaultValue = defaultValue
 }
 
 var wrappedValue: Value {
 get {
 UserDefaults.standard.object(forKey: self.key) as? Value ?? self.defaultValue
 }
 set {
 UserDefaults.standard.setValue(newValue, forKey: self.key)
 }
 }
 
 var projectedValue: Self {
 get {
 return self
 }
 }
 
 func removeValue() {
 UserDefaults.standard.removeObject(forKey: self.key)
 }
 }
 
 struct UserDefaultValues {
 @UserDefault(key: "isLogin", defaultValue: false) static var isLogin: Bool
 }
 
 UserDefaultValues.isLogin = false
 print(UserDefaultValues.isLogin)
 
 UserDefaultValues.isLogin = true
 print(UserDefaultValues.isLogin)
 
 UserDefaultValues.$isLogin.removeValue()
 print(UserDefaultValues.isLogin)
 */

//MARK: - typealias

/*
 typealias complitionHandeler<T> = (Result<T, Error>) -> Void
 
 func fetchUser(complition: @escaping complitionHandeler<String>) {
 // Body
 }
 */

//MARK: - Transforming a Optional value Using map

/*
 let date: Date? = Bool.random() ? Date() : nil
 let formatter = DateFormatter()
 let lbl = UILabel()
 
 lbl.text = date.map({formatter.string(from: $0)})
 print(date.map({formatter.string(from: $0)}))
 */

//MARK: - ExpressibleByStringLiteral

/*
 let url: URL = URL(string: "https://www.google.com")!
 
 extension URL: ExpressibleByStringLiteral {
 public init(stringLiteral value: StaticString) {
 self.init(string: "\(value)")!
 }
 }
 
 let url2: URL = "https://www.google.com"
 URLRequest(url: "https://www.google.com")
 */

//MARK: - Subscripting By Arrays

/*
 let data = [1, 2, 3]
 
 extension Collection {
 subscript (safe index: Index) -> Element? {
 return indices.contains(index) ? self[index] : nil
 }
 }
 
 print(data[safe: 1] as Any)
 print(data[safe: 5] as Any)
 */

//MARK: - KeyPath and Higher Oreder fun

/*
 let num = [1, 2, 3, 4]
 
 print(num.map(\.description))
 */

//MARK: - #file, #line, #function

/*
 func log(message: String,
 file: String = #file,
 line: Int = #line,
 function: String = #function) {
 print("[\(file): \(line)] \(function) - \(message)")
 }
 
 func foo() {
 log(message: "Hello")
 }
 
 foo()
 */

//MARK: - orEmpty

/*
 let txtField = UITextField()
 
 print(txtField.text ?? "")
 extension Optional where Wrapped == String {
 var orEmpty: String {
 switch self {
 case .none:
 return ""
 case .some(let wrapped):
 return wrapped
 }
 }
 }
 print(txtField.text.orEmpty)
 */

//MARK: - @discardableResult

/*
 @discardableResult
 func message() -> String {
 return "Hello"
 }
 
 print(message())
 
 let msg = message()
 print(msg)
 */

//MARK: - Zip

/*
 let num = [1,2,3,4]
 let str = ["a","b","!"]
 
 for (num, str) in zip(num, str) {
 print("\(num) \(str)")
 }
 */

/*
 @propertyWrapper
 struct FormatedDate {
 var formate: String
 
 var wrappedValue: Date
 var projectedValue: String {
 let formatter = DateFormatter()
 formatter.dateFormat = formate
 return formatter.string(from: wrappedValue)
 }
 
 init(wrappedValue: Date, formate: String = "dd/MM/yyyy") {
 self.wrappedValue = wrappedValue
 self.formate = formate
 }
 }
 
 
 enum GetDate {
 @FormatedDate static var date: Date = Date()
 }
 
 print(GetDate.$date)
 print(GetDate.date)
 */

//MARK: - Exam questions

//1. Question

class Bank {
    var customers: [Customer] = []
    
    func registerCustomer(firstName: String, lastName: String, email: String) -> Customer {
        let newId = customers.count + 1
        let sixDigitNum = Int(arc4random_uniform(1000000))
        let newCustomer = Customer(id: newId, firstName: firstName, lastName: lastName, email: email, balance: 0.0, accountNumber: sixDigitNum, transactions: [])
        customers.append(newCustomer)
        return newCustomer
    }
    
    func deposit(amount: Double, forCustomerWithId id: Int) -> Bool {
        for customer in customers {
            if customer.id == id {
                customer.balance += amount
                customer.transactions.append(Transaction(amount: amount, type: .deposit))
                return true
            }
        }
        return false
    }
    
    func withdraw(amount: Double, forCustomerWithId id: Int) -> Bool {
        for customer in customers {
            if customer.id == id {
                if customer.balance >= amount {
                    customer.balance -= amount
                    customer.transactions.append(Transaction(amount: amount, type: .withdrawal))
                    return true
                } else {
                    return false
                }
            }
        }
        return false
    }
    
    func getCustomer(byId id: Int) -> Customer? {
        for customer in customers {
            if customer.id == id {
                return customer
            }
        }
        return nil
    }
    
    func getStatement(forCustomerWithId id: Int) -> String {
        if let customer = getCustomer(byId: id) {
            var statement = "Account Holder: \(customer.firstName) \(customer.lastName)\n"
            statement += "Account Number: \(customer.accountNumber)\n"
            statement += "Balance: ₹\(customer.balance)\n"
            statement += "Transactions:\n"
            for (index, transaction) in customer.transactions.enumerated() {
                statement += "\(index + 1). \(transaction.type.rawValue) ₹\(transaction.amount)\n"
            }
            return statement
        }
        return "Customer not found."
    }
    
    func getTotalBalanceOfBank() -> String {
        "Total Balance bank has: ₹\(customers.reduce(0.0, { $0 + $1.balance }))"
    }
    
    func getAllCustomers() -> [Customer] {
        return customers
    }
    
    func getAllCustomersSortedByFirstName() -> [Customer] {
        return customers.sorted(by: { $0.firstName < $1.firstName })
    }
    
    func closeAccount(id: Int) -> Bool {
        guard let index = customers.firstIndex(where: { $0.id == id }) else {
            return false
        }
        customers.remove(at: index)
        return true
    }
}

enum TransactionType: String {
    case deposit
    case withdrawal
}

struct Transaction {
    var amount: Double
    var type: TransactionType
}

class Customer {
    var id: Int
    var firstName: String
    var lastName: String
    var email: String
    var accountNumber: Int
    var balance: Double
    var transactions: [Transaction]
    
    init(id: Int, firstName: String, lastName: String, email: String, balance: Double, accountNumber: Int, transactions: [Transaction]) {
        self.id = id
        self.firstName = firstName
        self.lastName = lastName
        self.email = email
        self.balance = balance
        self.accountNumber = accountNumber
        self.transactions = transactions
    }
}

let bank = Bank()
bank.registerCustomer(firstName: "Akash", lastName: "Boghani", email: "akash@gmail.com")
bank.registerCustomer(firstName: "Pruthvi", lastName: "Patel", email: "pruthvi@gmail.com")

bank.deposit(amount: 1000, forCustomerWithId: 1)
bank.withdraw(amount: 100, forCustomerWithId: 1)
print(bank.getStatement(forCustomerWithId: 1))
print(bank.getStatement(forCustomerWithId: 2))

print(bank.getAllCustomers().map({$0.email}))
print(bank.getAllCustomersSortedByFirstName().map({$0.email}))

print(bank.getTotalBalanceOfBank())







